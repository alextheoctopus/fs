package com.itmo.featurestore


class FeatureStoreService : FeatureStore.FeatureStoreImplBase() {
    override fun put(request: Api.PutRequest?, responseObserver: StreamObserver<Api.PutResponse>?) {
        super.put(request, responseObserver)
    }

    override fun get(request: Api.GetRequest?, responseObserver: StreamObserver<Api.GetResponse>?) {
        super.get(request, responseObserver)
    }
}